typedef struct Point {
    int row;
    int col;
} Point;
